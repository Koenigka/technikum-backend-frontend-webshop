$("#stickyfooterContainer").load("/components/footer/footer-sticky.html");
