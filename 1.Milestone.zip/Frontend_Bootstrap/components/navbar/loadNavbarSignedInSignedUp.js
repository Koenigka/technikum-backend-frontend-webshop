$("#navbarContainerLogin").load("/components/navbar/navbar-signin-signup.html");
